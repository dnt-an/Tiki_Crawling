-- SQLite
SELECT * FROM categories
                    ;